package model;

public class user {
}
